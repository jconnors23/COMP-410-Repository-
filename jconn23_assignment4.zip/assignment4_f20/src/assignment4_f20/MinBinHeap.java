package assignment4_f20;

public class MinBinHeap implements Heap {
	private CacheFrame[] array; // load this array
	private int size; // how many items currently in the heap
	private int arraySize; // Everything in the array will initially
							// be null. This is ok! Just build out
							// from array[1]

	public MinBinHeap(int nelts) {
		this.array = new CacheFrame[nelts + 1]; // remember we dont use slot 0
		this.arraySize = nelts + 1;
		this.size = 0;
		this.array[0] = new CacheFrame(null, 0); // 0 not used, so this is arbitrary
	}

	// Please do not remove or modify this method! Used to test your entire Heap.
	@Override
	public CacheFrame[] getHeap() {
		return this.array;
	}

	@Override
	public void insert(CacheFrame elt) {
		// TODO Auto-generated method stub
		// cache object has string, val, and frequency
		elt.setSlot(size() + 1);
		array[size + 1] = elt;
		size++;
		bubblebookUp(size);
		return;
	}

	@Override
	public void delMin() {
		// TODO Auto-generated method stub
		// el at root removed
		if (size() == 0) {
			return;
		}
		// CacheFrame minF = getMin();
		array[1] = array[size()];
		array[1].setSlot(1);
		array[size] = null; 
		size--;
		//System.out.println("right b4 bdown");
		bubblebookDown(1);
		return;
	}

	private void bubblebookDown(int start) { // start = index at which bubble down begins
		System.out.println("bubble down :)"); 
		int child;
		CacheFrame temp = array[start];
		for (; start * 2 <= size(); start = child) {
			child = start * 2;
			if (child != size() && array[child + 1].getPriority() < array[child].getPriority()) {
				//System.out.println("first if reached bdwon");
				child++;
			}
			if (array[child].getPriority() < temp.getPriority()) {
				//System.out.println("second if reached bdown");
				CacheFrame Whosiahstemp = array[start]; 
				array[start] = array[child];
				array[child] = Whosiahstemp;
				array[start].setSlot(start);
				array[child].setSlot(child);
			} else {
				//System.out.println("else reached bdown");
				break;
			}
			//System.out.println("array of " + start + " " + array[start].getValue());
			//array[start] = temp; //System.out.println("array of " + start + " " + array[start].getValue()); 
			//array[start].setSlot(start);
		}
	}

	private void bubblebookUp(int start) { // start = index at which bubble up begins // who knows if right
		/*int child;
		CacheFrame temp = array[start];
		for (; start * 2 <= size(); start = child) {
			System.out.println("I like pie");
			child = start * 2;
			if (child != size() && array[child + 1].getPriority() > array[child].getPriority()) {
				child++;
			}
			if (array[child].getPriority() > temp.getPriority()) {
				array[start] = array[child];
				array[start].setSlot(start);
			} else {
				break;
			}
			array[start] = temp;
			array[start].setSlot(start);
		} */
		int child = start;
		while (array[child / 2] != null && array[child / 2].getPriority() > array[child].getPriority()) {
			/*if (array[parent + parent].getPriority() > array[parent].getPriority()) 
			{
				CacheFrame temp = array[parent];
				array[parent] = array[parent + parent]; 
				array[parent + parent] = temp;
			}
			if (array[parent + parent + 1].getPriority() > array[parent].getPriority()) {
				CacheFrame temp = array[parent];
				array[parent] = array[parent + parent + 1]; 
				array[parent + parent + 1] = temp;
			}
			parent  = parent * 2; 
			i = parent; */
			CacheFrame temp = array[child];
			array[child] = array[child / 2];
			array[child / 2] = temp; 
			array[child].setSlot(child);
			array[child / 2].setSlot(child / 2);
			child = child / 2;
			}
	}

	@Override
	public CacheFrame getMin() {
		// TODO Auto-generated method stub
		return array[1];
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		/*
		 * int i = 1; int count = 0; while (array[i] != null) { count++; i++; } size =
		 * count;
		 */
		return size;
	}

	@Override
	public void incElt(CacheFrame elt) {
		// TODO Auto-generated method stub
		if (size() == 0) {
			return;
		}
		if (elt.getPriority() > 0) {
			int prio = elt.getPriority();
			prio++;
			elt.setPriority(prio);
			int bubel = elt.getSlot();
			//System.out.println("new priority = " + prio); 
			bubblebookDown(bubel);
		}
		return; 
		// need to implement bubbling down as necessary + slot change reflections
	}

	@Override
	public void decElt(CacheFrame elt) {
		// TODO Auto-generated method stub
		if (size() == 0) {
			return;
		}
		if (elt.getPriority() > 1) {
			int prio = elt.getPriority();
			prio--;
			elt.setPriority(prio);
			int bubel = elt.getSlot();
			bubblebookUp(bubel);
		}
		return; 
		// need to implement bubbling down as necessary + slot change reflections
	}

	// ===============================================================
	//
	// here down you implement the ops in the interface
	//
	// ===============================================================

}