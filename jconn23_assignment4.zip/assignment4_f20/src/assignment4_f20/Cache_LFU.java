package assignment4_f20;

import java.util.HashMap;

public class Cache_LFU implements Cache {

	HashMap<String, CacheFrame> map;
	// allocate from java collections lib
	// do it this way so we all start with default size and
	// default lambda and default hash function for string keys
	MinBinHeap heap; // your own heap code above
	int limit; // max num elts the cache can hold
	int size; // current number elts in the cache

	Cache_LFU(int maxElts) {
		this.map = new HashMap<String, CacheFrame>();
		this.heap = new MinBinHeap(maxElts);
		this.limit = maxElts;
		this.size = 0;
	}

	// dont change this we need it for grading
	public MinBinHeap getHeap() {
		return this.heap;
	}

	public HashMap getHashMap() {
		return this.map;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return limit; // limit = max elts
	}

	@Override
	public int numElts() {
		// TODO Auto-generated method stub
		return size; // is size the same as# of frames in cache?
	}

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		if (limit == size) {
			return true; // is the number of items in the cache is the same as the max limit
		}
		return false;
	}

	@Override
	public boolean refer(String address) {
		// TODO Auto-generated method stub
		if (size() == 0) {
			return false;
		}
		if (map.containsKey(address)) {
			// need to figure out how to add frame and how to refernce priority
			// priority++;
			getHeap().incElt(map.get(address)); 
			//int prio = map.get(address).getPriority(); // priority
			//prio++;
			//map.get(address).setPriority(prio);
			return true;
		}
		if (isFull()) {
			map.remove(getHeap().getMin().getValue()); 
			//printHeap(getHeap().getHeap(), size);
			heap.delMin(); // have to remove a fram??????
			size--;
			//printHeap(getHeap().getHeap(), size);
			CacheFrame ncf = new CacheFrame(address, 1); // creating a new frame
			//map.put(address, ncf);
			//getHeap().insert(ncf); 
			//return false;
			// need to increment frames
		}
		CacheFrame ncf = new CacheFrame(address, 1); // creating a new frame 
		map.put(address, ncf);
		size++;
		getHeap().insert(ncf); 
		// need to increment frames ? the number of frames goes up by one if we add a
		// frame
		return false;
	}
	 public static void printHeap(CacheFrame[] e,int len) { 
		    // this method skips over unused 0th index....
		    System.out.println(len); 
		    System.out.println("Printing Heap");
		    for(int i=1; i< len+1; i++) {
		      System.out.print("(p."+e[i].value+",f"+e[i].priority+",s"+e[i].getSlot()+")\t");
		    }
		    System.out.print("\n");
		  }

	// =========================================================
	//
	// you fill in code for the other ops in the interface
	//
	// ==========================================================

}