package assignment4_f20;

public class Playground {
  public static void main(String[] args) {
    // Add more tests as methods and call them here!!
    RunMyTests();
    // etc.
  }

  public static void RunMyTests() {
   Cache_LFU lfc = new Cache_LFU(3);
    lfc.refer("AA8C");
    printHeap(lfc.getHeap().getHeap(), lfc.getHeap().size());
    lfc.refer("AA8C");
    printHeap(lfc.getHeap().getHeap(), lfc.getHeap().size());
    lfc.refer("1234");
    printHeap(lfc.getHeap().getHeap(), lfc.getHeap().size());
    lfc.refer("234A");
    printHeap(lfc.getHeap().getHeap(), lfc.getHeap().size());
    lfc.refer("AA8C");
    printHeap(lfc.getHeap().getHeap(), lfc.getHeap().size());
    lfc.refer("1234");
    printHeap(lfc.getHeap().getHeap(), lfc.getHeap().size());
    lfc.refer("ABCD");
    /*lfc.refer("234A");
    lfc.refer("ABCD");
    lfc.refer("1101");
    lfc.refer("2202"); lfc.refer("2202");
    lfc.refer("2202"); lfc.refer("2202"); */
    
 // Test Failed:refer("AA8C") x 2, refer("1234"), refer("234A"), refer("AA8C"), refer("1234"), refer("ABCD") 
    //-> Arrays.toString(getHeap()) --> Expected [(val: ABCD, pri:1, slot: 1), (val: AA8C, pri:3, slot: 2), (val: 1234, pri:2, slot: 3)], saw [(val: 234A, pri:1, slot: 1), (val: AA8C, pri:3, slot: 2), (val: ABCD, pri:1, slot: 3)] 
    //expected:<[(val: [ABCD, pri:1, slot: 1), (val: AA8C, pri:3, slot: 2), (val: 1234, pri:2], slot: 3)]> but was:<[(val: [234A, pri:1, slot: 1), (val: AA8C, pri:3, slot: 2), (val: ABCD, pri:1], slot: 3)]>
   
    System.out.println(lfc.size());
    System.out.println(lfc.numElts());
    printHeap(lfc.getHeap().getHeap(), lfc.getHeap().size());
 
    // etc.

  }

  public static void printHeap(CacheFrame[] e,int len) { 
    // this method skips over unused 0th index....
    System.out.println("Printing Heap");
    for(int i=1; i< len+1; i++) {
      System.out.print("(p."+e[i].value+",f"+e[i].priority+",s"+e[i].getSlot()+")\t");
    }
    System.out.print("\n");
  }

}