package assignment2_f20;

public class TreeMap_imp implements TreeMap {
	TMCell root;
	int count = 0; // starts at 0
	int size = 0;
	// String[] keyArray = new String[size];
	// add fields as you need to in order to provide the required behavior
	// also you may add private methods to assist you as needed
	// in implementing

	// -------------------------------------------------------------

	TreeMap_imp() {
		root = null;
		// for added fields you can add appropriate initialization code here
	}

	// -------------------------------------------------------------

	// dont change, we need this for grading
	@Override
	public TMCell getRoot() {
		return this.root;
	}

	// -------------------------------------------------------------
	// "height" is a complete implementation
	// of the public interface method height
	// it is here to illustrate fr you how the textbook sets up
	// the method implementation as recursion
	// you may include this in your project directly

	public int height() { // public interface method signature
		// this method is the public interface method
		// it is not recursive, but it calls a recursive
		// private method and passes it access to the tree cells
		return height_r(this.getRoot());
	}

	private int height_r(TMCell c) {
		// inner method with different signature
		// this helper method uses recursion to traverse
		// and process the recursive structure of the tree of cells
		if (c == null)
			return -1;
		int lht = height_r(c.getLeft());
		int rht = height_r(c.getRight());
		return Math.max(lht, rht) + 1;
	}

	@Override
	public Value put(String k, Value v) {
		// TODO Auto-generated method stub
		Value putt = put_r(this.getRoot(), k, v);
		return putt; 
		// return null;
	}

	private Value put_r(TMCell c, String k, Value r) { // what happens if get to end and what ahppens if get to element
        
		if (c == null) { // since c is null have to add key and value to the structure before returning
							// null
			c = new TMCell_imp(k, r);
			this.root = c;
			return null;
		}
		if (hasKey(k) == true) {
			// isithere[i].setvalue() ==
			Value returnvalobj = c.getValue(); // replace the value obj in the cell with the new one
			c.setValue(r);
			return returnvalobj; // return the old value object
		}

		if (c.getKey().compareTo(k) > 0) {// switch order? if the key is greater than
			if (c.getLeft() == null) {
				size++; 
				c.setLeft(new TMCell_imp(k, r)); // setting key and value of left child
				return null;
			}
			//size++; 
			return put_r(c.getLeft(), k, r); // recursive call
		} else {
			if (c.getRight() == null) {
				size++; // if c right child is null
				c.setRight(new TMCell_imp(k, r)); // setting key and value of right child
				return null;
			}
			//size++; 
			return put_r(c.getRight(), k, r); // recursive call
			// return null;
		}
	}

	@Override
	public Value get(String k) {
		// TODO Auto-generated method stub
		// get: in: a string (the key) return: a Value object, or null effect: if key is
		// * NOT in the structure return null (this includes when the structure is
		// empty,
		// * size 0) if key IS in the structure return the Value object from the cell
		// * containing the key
		// private val get_r, (TM cell c, string k)

		Value getter = get_r(this.getRoot(), k);
		return getter; 
	}

	private Value get_r(TMCell c, String k) {

		if (c == null) { // root is empty
			return null;
		}
		int cResult = k.compareTo(c.getKey()); // integer for comparison
		if (cResult < 0) {
			return get_r(c.getLeft(), k); // recursive call
		} else if (cResult > 0) {
			return get_r(c.getRight(), k); // recursive call
		} else {
			return c.getValue(); // keys match so return the value
		}
	}

	@Override
	public void remove(String k) {
		// TODO Auto-generated method stub
		remove_r(this.getRoot(), k, null);
	}

	private void remove_r(TMCell c, String k, TMCell parent) {
		if (hasKey(k) == false) {
			return;
		} 
		//can passs in pare
		int cResult = k.compareTo(c.getKey()); // integer for comparison
		if (cResult < 0) {
			remove_r(c.getLeft(), k, c);
		} else if (cResult > 0) {
			remove_r(c.getRight(), k, c);
		} else {
			if (parent.getLeft() == c) {
				if (c.getLeft() == null && c.getRight() == null) {
					parent.setLeft(null);
					size--; 
				} 
			}
			if (parent.getRight() == c) {
				if (c.getLeft() == null && c.getRight() == null) {
					parent.setRight(null);
					size--; 
				}
			}
			if (parent.getLeft() == c) {
				if (c.getLeft() != null && c.getRight() == null) {
					parent.setLeft(c.getLeft()); 
					size--; 
				}
			}
			if (parent.getLeft() == c) {
				if (c.getLeft() == null && c.getRight() != null) {
					parent.setLeft(c.getRight()); 
					size--; 
				}
			}
			if (parent.getRight() == c) {
				if (c.getRight() != null && c.getLeft() == null) {
					parent.setRight(c.getRight()); 
					size--; 
				}
			}
			if (parent.getRight() == c) {
				if (c.getRight() == null && c.getLeft() != null) {
					parent.setRight(c.getLeft()); 
					size--; 
				}
			}
			// both childs block 
			if (parent.getLeft() == c) {
				if (c.getLeft() != null && c.getRight() != null) {
					TMCell hasnullval = getnullRLChild_r(c.getRight()); 
					//remove_r(c,hasnullval.getKey(), c.getLeft()); 
					//remove_r(hasnullval, k, c.getLeft());
					remove_r(hasnullval, c.getRight().getKey(), parent); 
					parent.setLeft(hasnullval); 
					size--; 
				}
			}
			if (parent.getRight() == c) {
				if (c.getLeft() != null && c.getRight() != null) {
					TMCell hasnullval = getnullRLChild_r(c.getRight()); 
					parent.setRight(hasnullval); 
					remove_r(hasnullval, c.getRight().getKey(), parent); 
					size--; 
				}
			}
		}
	}


	private TMCell getnullRLChild_r(TMCell c) {
		// TODO Auto-generated method stub
		if (c.getLeft() == null) {
			return c; 
		}
		if (c.getLeft() != null) {
			return getnullRLChild_r(c.getLeft()); 
		}
		return c;
	}

	@Override
	public boolean hasKey(String k) {
		// TODO Auto-generated method stub
		boolean hasKey = haskey_r(this.getRoot(), k);
		return hasKey;
	}

	private boolean haskey_r(TMCell c, String k) {
		if (c == null) { // root is empty
			return false;
		}
		int cResult = k.compareTo(c.getKey()); // integer for comparison
		if (cResult < 0) {
			return haskey_r(c.getLeft(), k);
		} else if (cResult > 0) {
			return haskey_r(c.getRight(), k);
		} else {
			return true; // keys match
		}
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public String maxKey() { // getting null pointer exception in testing oracle
		// TODO Auto-generated method stub
		if (this.getRoot() == null) {
			return null;
		} // else if (this.root.getLeft() == null) {
			// return this.root.getLeft().getKey();
			// }
		String maxKey = maxKey_r(this.getRoot());
		return maxKey; 
	}

	private String maxKey_r(TMCell c) { // getting null pointer exception in testing oracle 
		// TODO Auto-generated method stub
		if (c == null) {
			return null;
		} 
		if (c.getRight() == null) {
			return c.getKey();
		}
		return maxKey_r(c.getRight());
	}

	@Override
	public String minKey() {  // getting null pointer exception in testing oracle
		// TODO Auto-generated method stub
		if (this.getRoot() == null) {
			return null;
		} // else if (this.root.getLeft() == null) {
			// return this.root.getLeft().getKey();
			// }
		String minKey = minKey_r(this.getRoot()); // changed from thisroot to get Root
		return minKey; 
		
	}

	private String minKey_r(TMCell c) { // getting null pointer exception in testing oracle
		// TODO Auto-generated method stub
		if (c == null) {
			return null;
		} 
		if (c.getLeft() == null) {
			return c.getKey();
		}
		return minKey_r(c.getLeft());
	}

	@Override
	public String[] getKeys() {
		// TODO Auto-generated method stub
		// String[] keyArray = new String[1000000000];

		// String[] returnkeyArray = getKeys_r(this.root); // dont need this can put
		// getKeys_r method in here
		// return returnkeyArray;
		String[] keyArray = new String[size];
		count = 0;
		keyArray = (getKeys_r(this.getRoot(), keyArray));
		return keyArray;
	}

	private String[] getKeys_r(TMCell c, String[] keyArray) {
		// TODO Auto-generated method stub
		// String[] keyArray = new String[1000000000];

		if (size() == 0) {
			return keyArray;
		}

		if (c.getLeft() != null) {
			getKeys_r(c.getLeft(), keyArray); // return would kill method
		}
		keyArray[count] = c.getKey();
		count++;
		if (c.getRight() != null) {
			getKeys_r(c.getRight(), keyArray); // return would kill method
		}
		return keyArray;
	}

	// -------------------------------------------------------------
	// here down... you fill in the implementations for
	// the other interface methods
	// -------------------------------------------------------------
	//
	// remember to implement the required recursion as noted
	// in the interface definition
	//
	// -------------------------------------------------------------

}