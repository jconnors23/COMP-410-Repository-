package assignment1;

public class StackSetPlayground {

  public static void main(String[] args) { 
    /*
     here you can instantiate your StackSet and play around with it to check correctness. 
     We've graciously also provided you a bit of extra test data for debugging.
     It doesn't matter what you have in here. We will not grade it. 
     This is for your use in testing your implementation.
    */
    /* StackSet set = new StackSet(3);
    System.out.println(set);
    set.push(1);
    set.push(2);
    System.out.println(set);
    set.push(1);
    System.out.println(set);
    System.out.println(set.pop());
    set.push(1);
    set.push(2);
    set.push(3);
    System.out.println(set);
    set.push(4);
    System.out.println(set);
    */
	 
	StackSet set = new StackSet(4);
	set.push(1); 
	set.push(2);
	set.push(3);
	
	// System.out.print(set.peek());
	set.push(4);
	// System.out.print(set.peek());
	System.out.print(set.push(5));
	
	
  }
  
}





/* int count = 0;
while (count < size) {
	Node desired = head.getNext(); // get the next node in the list
	if (elt == desired.getValue()) { // if n = next value in the list, move that next value to the front of the
										// list
		head.ins(desired, elt); // should insert the node at the first element???
		return true; // size doesnt change, we moved the value to the front and we are done
	} else {
		count++; // increase the count, first iteration
	}
	if (count == size) { // will only enter this section of while loop if the count = size, otherwise
							// keeps iterating
		if (size == limit) {
			return false; // cant add more elements to list so returns false
		} else if (size < limit) { // n is not already in list, and list has available space, we insert n at
									// front of the list
			Node wanted = null; // the node we will insert at the front with the needed value
			head.ins(wanted, elt);
			// wanted.getNext()
			size++;
			return true;
		}
	}
} */ 