package assignment1;

public interface Node {
  
public double getValue();
  public void setNext(Node next);
  public Node getNext();
  // public void ins(Node node, int i); // for moving element to the front via push method 
  // public void ins(Node desired, int i);
 
}