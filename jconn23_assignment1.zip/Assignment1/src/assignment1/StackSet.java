/**
 * COMP 410
 * See inline comment descriptions for methods we need that are
 * not described in the interface.
 *
*/
package assignment1;

import java.util.*;

public class StackSet implements StackSet_Interface {
	private Node head; // this will be the entry point to your linked list
						// ( it points to the first data cell, the top for a stack )
	private final int limit; // defines the maximum size the stackset may contain
	private int size; // current count of elements in the stackset

	public StackSet(int maxNumElts) { // this constructor is needed for testing purposes.
		head = null; // Please don't modify what you see here!
		limit = maxNumElts; // you may add fields if you need to
		size = 0;
	}

	// implement all methods of the interface, and
	// also include the getRoot method below that we made for testing purposes.
	// Feel free to implement private helper methods!
	// you may add any fields you need to add to make it all work...

	public Node getRoot() { // leave this method as is, used by the grader to grab
		return head; // your data list easily.
	}

	@Override
	public boolean push(double elt) {
		// TODO Auto-generated method stub
		if (peek() == Double.NaN) { // if empty
			if (size == limit) {
				return false;
			} else {
				Node wanted = new NodeImpl(elt); // constructor called
				head = wanted;
				size++;
				return true;
			}
		}
		double current = peek(); // get the first value in the list, getting null pointer exception but why? null pointer resolved 

		if (elt == current) {
			return true; // n is already at the front, we are done
		}
		if (contains(elt)) { // if the linked list contains the value we want already 
			// have to move it to the top
			Node current3 = head; // variable set to head
			for (int i = 1; i <= size - 1; i++) { // theorical glitches
				if (current3.getNext().getValue() == elt) {
					// come to top
					Node temp = current3.getNext();
					current3.setNext(current3.getNext().getNext()); //setting curr3 next node value to be two spaces ahead 
					Node temp2 = head; 
					head = temp; //setting head to next node in list (current3.getNext()) 
					temp.setNext(temp2); // new heads next value will be current head 
				} else {
					current3 = current3.getNext(); // else iterate again 
				}
			}
			return true; // need return statement here 

		}

		if (size == limit) {
			return false;
		} else if (size < limit) {
			Node wanted = new NodeImpl(elt, head);
			head = wanted;
			size++;
			return true;
		}

		return false;
		// return false;
	}

	@Override
	public boolean pop() { 
		// TODO Auto-generated method stub
		if (isEmpty()) {
			return false;
		} else {
			Node newhead = head.getNext();
			head = newhead; 
			size--;
			return true;
		}
	}

	@Override
	public double peek() {
		// TODO Auto-generated method stub
		if (size >= 1) {
			return head.getValue();
		} else {
			if (isEmpty()) {
				return Double.NaN;
			}
		}
		return 0;
	}

	@Override
	public boolean contains(double elt) {
		// TODO Auto-generated method stub
		Node current2 = head;
		for (int i = 1; i <= size; i++) {

			if (current2.getValue() == elt) { // head is the same
				return true;
			} else {
				current2 = current2.getNext();
				if (i >= size) {
					return false;
				}
			}
		}
		return false;
	}

	@Override
	public int size() { // why is this here?????
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int limit() {
		// TODO Auto-generated method stub

		return limit;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		if (size == 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		if (size >= limit) {
			return true;
		}
		return false;
	}

}