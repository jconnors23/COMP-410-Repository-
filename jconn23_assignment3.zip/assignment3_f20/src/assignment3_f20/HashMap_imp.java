package assignment3_f20;

// import com.sun.org.apache.xalan.internal.xsltc.runtime.Node;

public class HashMap_imp implements HashMap {
	HMCell[] tab;
	int nelts;
	//int size; 

	// -------------------------------------------------------------

	HashMap_imp(int num) {
		this.tab = new HMCell[num];
		// for (int i=0; i<num; i++) { tab[i] = null; }
		// we can rely on the Java compiler to fill the table array with nulls
		// another way would be Array.fill()
		this.nelts = 0;
	}

	// -------------------------------------------------------------

	public int hash(String key, int tabSize) {
		int hval = 7;
		for (int i = 0; i < key.length(); i++) {
			hval = (hval * 31) + key.charAt(i);
		}
		hval = hval % tabSize;
		if (hval < 0) {
			hval += tabSize;
		}
		return hval;
	}

	// -------------------------------------------------------------

	// dont change
	@Override
	public HMCell[] getTable() {
		return this.tab;
	}

	@Override
	public Value put(String k, Value v) {
		// TODO Auto-generated method stub
		// call hash to put key value pair in correct spot 
		int index = hash(k, tab.length); 
		HMCell temp = new HMCell_imp(k, v); 
		/*if (size() == 0) { // key is not in structure if size is zero
			//create new HMCell???
			//temp = tab[0]; 
			//tab[0].setKey(k); // set key // NULL POINTER HERE BUT Y 
			//tab[0].setValue(v); // set val
			tab[index] = temp;
			nelts++; 
			double oneg = lambda(); // check lambda
			if (oneg >= 1) {
				extend(); // perform extend to handle chaining 
			}
			return null; 
		} */
		if (!hasKey(k)) { // if it doesnt have the key 
			//tab[nelts].setKey(k); // set key // NULL POINTER HERE BUT Y 
			//tab[nelts].setValue(v); // set val
			if (tab[index] != null) {
				temp.setNext(tab[index]);
			} 
				tab[index] = temp;
				
			nelts++;
			double oneg = lambda(); // check lambda
			if (oneg >= 1) {
				extend(); // perform extend to handle chaining 
			}
			return null; 
		}
		/*if (tab[index] == null) { // if its null just place 
			temp.setKey(k); // set key 
			temp.setValue(v); // set val
			tab[index] = temp; 
			return null;
		} */
		if (hasKey(k)) { // wont need new cell if key is in structure already
			HMCell water; // temp temp named water 
			water = tab[index]; // chain handling 
				while (water != null) 
				{
					if (water.getKey().compareTo(k) == 0) 
					{
						Value returnval = water.getValue(); 
						water.setValue(v); // new val 
						Value newval = water.getValue(); // new value
						//tab[index].setValue(newval); // WRONG LOGIC HERE HAVE TO GO DOWN CHAIN 
						/*for (int i = 0; i < size(); i++) 
						{
							HMCell chainindex;
							chainindex = tab[i];               // FOR LOOP SHOULD ACCOUNT FOR CHAINING this for loop is a correct 
							while (chainindex != null) {           // version of line 90 
								if (chainindex.getKey().compareTo(k) == 0) {
									tab[i].setValue(newval);
								}
								chainindex = chainindex.getNext(); 
							}  
						} */
						double oneg = lambda(); // check lambda
						if (oneg >= 1) {
							extend(); // perform extend to handle chaining 
						}
						return returnval; // return old value object 
					}
					water = water.getNext(); 
				}
			}
			//Value returnval = tab[index].getValue();
			//tab[index].setValue(v);
			//double oneg = lambda(); // check lambda
			//if (oneg >= 1) {
			//	extend(); // perform extend to handle chaining 
			//}
			//return returnval; // return old value object
		/*if (!hasKey(k) && size() != 0) { // if it doesnt have the key and the table is not null 
			temp.setKey(k); // set key // UNNECESSARY PROBS DELETE LATER WONT EVER REACH BOTH OF THESE CONDITIONS??? 
			temp.setValue(v); // set val
			tab[index].setKey(temp.getKey()); 
			tab[index].setValue(temp.getValue()); ; 
			nelts++;
			double oneg = lambda(); // check lambda
			if (oneg >= 1) {
				extend(); // perform extend to handle chaining 
			}
			return null; 
		} */
		return null;
	}
	@Override
	public Value get(String k) {
		// TODO Auto-generated method stub
		if (size() == 0) { // size is zero, structure is empty, return null
			return null;
		}
				/*if (tab[i].getKey().compareTo(k) == 0) { // if the keys match, return respective val 
					return tab[i].getValue();  // redundant 
				} */ 
			
			// next we account for chaining 
			int i = hash(k, tab.length); 
			HMCell temp; // sus on null pointer being here due to i < size, should it be i < size - 1??? 
			temp = tab[i]; 
			while (temp != null) {
				if (temp.getKey().compareTo(k) == 0) {
					return temp.getValue();
					}
				temp = temp.getNext(); 
			} 
		return null;
	}
	// private Value get_r(String k) {
	// TODO Auto-generated method stub
	// return k;
	// }

	@Override
	public void remove(String k) {
		// TODO Auto-generated method stub
		if (size() == 0) {
			return; 
		}
			/*if (tab[i].getKey().compareTo(k) == 0) { redundant 
				// need removal here 
				nelts--; 
			} */ 
			// next we account for chaining // chain check not necessary??? 
			// WHAT IF SIZE IS 1 ???? 
		    int i = hash(k, tab.length); 
			HMCell temp;
			HMCell prev;
			temp = tab[i];
			prev = null;
			while (temp != null) {
			if (temp.getKey().compareTo(k) == 0) { // if in the structure 
				//tab[i - 1].setNext(tab[i + 1]); // set previous to the next tab value 
				//tab[i].setKey(null); // set current to null it is being removed 
				//tab[i].setValue(null); // ^^
				if (prev == null) {
				    tab[i] = (temp.getNext());
				} else {
					prev.setNext(temp.getNext());
				}
				nelts--; // decrement element count 

			}
			    prev = temp;
				temp = temp.getNext(); 
			}  
		//nelts--;
		return; // if not in the structure 
	}

	@Override
	public boolean hasKey(String k) {
		// TODO Auto-generated method stub
		if (size() == 0) { // simple size check first 
			return false; 
		}
			// next we account for chaining // chain check not necessary??? 
		    int i = hash(k, tab.length); 
			HMCell temp;
			temp = tab[i]; 
			while (temp != null) {
				if (temp.getKey().compareTo(k) == 0) {
					return true;
				}
				temp = temp.getNext(); 
			}  
		return false;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		if (nelts == 0) {
			return 0; 
		}
		return nelts;
	}

	@Override
	public String maxKey() {
		// TODO Auto-generated method stub
		if (size() == 0) {
			return null; 
		}
		/*String[] checkmax = getKeys(); // retrieve our keys 
		String tempmax = checkmax[0]; //temporary max 
		for (int i = 0; i < size(); i++) {
			if (i + 1 >= size()) { // to account for null pointer exception for the next if statement
				return tempmax; 
			}
			if (checkmax[i + 1].compareTo(tempmax) == 1) { // if the string key is greater 
				tempmax = checkmax[i + 1]; 
			}
		} */
		String tempmax = null; 
		HMCell temp;  
		for (int i = 0; i < tab.length; i++) 
		{
			temp = tab[i];
			while (temp != null) { 
				// iffy get keys
				tempmax = temp.getKey();
				if (temp.getKey().compareTo(tempmax) > 0) 
				{
					tempmax = temp.getKey();
					//temp = temp.getNext(); 
				}
				temp = temp.getNext(); 
			}

	    }
		return tempmax; 
	}

	@Override
	public String minKey() {
		// TODO Auto-generated method stub
		if (size() == 0) {
			return null; 
		}
		/*String[] checkmin = getKeys(); // retrieve our keys 
		//String tempmin = checkmin[0]; //temporary min 
		for (int i = 0; i < tab.length-1; i++) {
			if (i + 1 >= tab.length) { // to account for null pointer exception for the next if statement
				return tempmin; 
			}
			if (checkmin[i + 1].compareTo(tempmin) == -1) { // if the string key is smaller 
				tempmin = checkmin[i + 1]; 
			}
		} 
		return tempmin; */
		String tempmin = null; 
		HMCell temp;  
		for (int i = 0; i < tab.length; i++) 
		{
			temp = tab[i];
			while (temp != null) { 
				// iffy get keys
				tempmin = temp.getKey();
				if (temp.getKey().compareTo(tempmin) < 0) 
				{
					tempmin = temp.getKey();
					//temp = temp.getNext(); 
				}
				temp = temp.getNext(); 
			}
	    }
	    return tempmin; 
	}

	@Override
	public String[] getKeys() {
		// TODO Auto-generated method stub
		String[] keyArray = new String[nelts]; 
		if (size() == 0) {
			
			return keyArray; 
		}
		int c = 0; 
		for (int i = 0; i < tab.length; i++) 
		{
			/* if (tab[i] != null) // null check unnecessary???? redundancy 
			{
				keyArray[i] = tab[i].getKey(); 
			} */ 
			HMCell temp;                            // chain check may be inappropriate ? 
			temp = tab[i]; 
			while (temp != null) {                    // iffy get keys
				keyArray[c] = temp.getKey(); 
				c++;
				temp = temp.getNext(); 
			}
		}
		return keyArray;
	}

	@Override
	public double lambda() {
		// TODO Auto-generated method stub
	    // ensuring that table length and lambda vals are calculated as doubles 
		return (double) nelts / (double) tab.length; 
	}

	@Override
	public double extend() {
		// TODO Auto-generated method stub
		nelts = 0;
		int wedouble = tab.length + tab.length;
		// HMCell temp;
		HMCell water;
		HMCell[] newtab = new HMCell[wedouble];
		HMCell[] oldtab = tab;
		tab = newtab; // 	new table that is double in size	
		for (int i = 0; i < oldtab.length; i++) {
			//int i = hash(k, tab.length); 
			//temp = tab[i]; 
			water = oldtab[i];
			//System.out.println(water.getKey());
			
			while (water != null) { //chaining condition 
				System.out.println(water.getKey());
				//String sk = water.getKey();
				//Value skw = put(sk, water.getValue());
				//int newindex = hash(sk, wedouble);
				//HMCell temp2 = new HMCell_imp(sk, skw);
				put(water.getKey(),water.getValue()); 
				water = water.getNext();
			}
			/*if (temp == null) {
				continue; // if null iteratre again  
			}
			String sk = temp.getKey();
			Value skw = put(sk, temp.getValue());
			int newindex = hash(sk, wedouble); //calculates hash val but where do we put the hash val if necessary? 
			HMCell temp2 = new HMCell_imp(sk, skw); //STACK OVERFLOW ?????????????????????
			newtab[newindex] = temp2; 
			*/
			//newtab[newindex].setKey(temp.getKey()); // set the kew in new table  
			//newtab[newindex].setValue(put(temp.getKey(), temp.getValue())); // set the val in the new table 
		}
		tab = newtab; 
		double rlambda = lambda(); // calculate new lambda value  
		return rlambda;
	}

	// -------------------------------------------------------------

	// -------------------------------------------------------------
	// here down... you fill in the implementations for
	// the other interface methods
	// -------------------------------------------------------------
	/* int ghval = hash(k, nelts); 
	if (tab[ghval] != null) {
		while (tab[ghval].getNext() != null) 
		{
			// need iteration statement 
			if (tab[ghval].getNext().getKey() == k) 
			{
				return tab[ghval].getNext().getValue();
			}	
			HMCell current = tab[ghval].getKey(); 
			current = tab[ghval].getNext(); 
			
		}
	}
	*/ 
	/*for (int i = 0; i < size(); i++) 
	{
		if (tab[i] != null) 
		{
			while (tab[i].getNext() != null) 
			{
				if (tab[i].getNext().getKey() == k) 
				{
					return tab[i].getNext().getValue();
	}	
	}
	// need to traverse through to account for chaining 
	//if (tab[i].getKey() == k) 
	//{
		//return tab[i].getValue();
	//}
//	}
} */
// Value returnval = get_r(k) {}

}